const products = [
    new Product(
        [
            "../assets/img/jacket-1.jpg",
            "../assets/img/jacket-2.jpg",
            "../assets/img/jacket-3.jpg",
        ],
        "Jacket",
        100,
        ["#FF0000", "#00FF00", "#0000FF"],
        ["S", "M", "L"]
    ),
    new Product(
        [
            "../assets/img/jacket-2.jpg",
            "../assets/img/jacket-1.jpg",
            "../assets/img/jacket-3.jpg",
        ],
        "Windbreaker",
        120,
        ["#FFFF00", "#FF00FF", "#00FFFF"],
        ["S", "M", "L", "XL"]
    ),
    new Product(
        [
            "../assets/img/jacket-3.jpg",
            "../assets/img/jacket-2.jpg",
            "../assets/img/jacket-1.jpg",
        ],
        "Coat",
        150,
        ["#FFFFFF", "#000000"],
        ["M", "L", "XL"]
    ),
    new Product(
        [
            "../assets/img/jacket-2.jpg",
            "../assets/img/jacket-3.jpg",
            "../assets/img/jacket-1.jpg",
        ],
        "Cloack",
        130,
        ["#FFFFFF", "#000000"],
        ["M", "L", "XL"]
    ),
    new Product(
        [
            "../assets/img/jacket-3.jpg",
            "../assets/img/jacket-3.jpg",
            "../assets/img/jacket-1.jpg",
        ],
        "Cloack",
        130,
        ["#FFFFFF", "#000000"],
        ["M", "XXL", "XL"]
    ),
  ];
  